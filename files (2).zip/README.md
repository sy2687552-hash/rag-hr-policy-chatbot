# NexaSphere HR Policy Assistant (RAG)

Employees ask questions → answers come only from the uploaded HR policy, with sources shown.

## Run
```bash
pip install -r requirements.txt
export GEMINI_API_KEY=your_key   # or ANTHROPIC_API_KEY=sk-ant-...  (optional; without it, answers are extractive (0 tokens)
python app.py                          # open http://localhost:5000
```
Upload a new policy (PDF/DOCX/TXT) from the sidebar at any time.

## Token efficiency
- Retrieval is local (TF-IDF) — no embedding API calls
- Only top 3 sections (<=2,600 chars) go to the model; output capped at 350 tokens
- Haiku-tier model by default (`CLAUDE_MODEL` to override); repeated questions are cached
- Off-topic questions are rejected before any API call
